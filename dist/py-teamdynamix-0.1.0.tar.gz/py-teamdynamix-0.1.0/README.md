# py-tdx
Python client for interacting with the TeamDynamix ITSM APIs
