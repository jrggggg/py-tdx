from ..pytdx.tdx import Asset

assets = Asset()

print(assets)
